public class Pig 

{
    private String color;
    private double weight;
    private int size;
    private boolean walmud;
    
     
     
    //  System.out.print(name);
    //  System.out.print(weight);
    //  System.out.print(age);
    //  System.out.print(gender);
    //  System.out.print(makeNoise);
    //  System.out.print(haveBirthday);
      
    public Pig (String color, int size,  boolean walmud, double weight)
    {
        this.color = color;
        this.weight = weight;
        this.size = size;
        this.walmud = walmud;
    }

    public Pig()
    {
        this.color = "Bacon";
        this.weight = 50.00;
        this.size = 7;
        this.walmud = true;
    }


    public void makeNoise()
        {
            System.out.println("Pigs say: OINK OINK OINK");
        }
    public void upgradePenSize(int num)
    {
        size+=num;
    }
    
    public void displayPig()
    {
        System.out.println("The pig's color: " + color);
        System.out.println("The pig's weight: " + weight);
        System.out.println("The pig's size: " + size);
        System.out.println("Is the pig muddy?: " + walmud);
    }
        
} //end Pig class