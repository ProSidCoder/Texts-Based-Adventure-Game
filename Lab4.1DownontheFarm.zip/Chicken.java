public class Chicken 

{
      private String breed;
      private double weight;
      private int eggs;
      private boolean mean;
     
     
     
    //  System.out.print(breed);
    //  System.out.print(weight);
    //  System.out.print(eggs);
    //  System.out.print(mean);
    //  System.out.print(makeNoise);
    //  System.out.print(haveBirthday); 
      
      public Chicken(String breed, int eggs, boolean mean, double weight)
      {
          this.breed = breed;
          this.eggs = eggs;
          this.mean = mean;
          this.weight = weight;

      }

    public Chicken()
        {
            this.breed = "Chuck";
            this.weight = 20.00;
            this.eggs = 3;
            this.mean = false;
        }
    
    
    public void makeNoise()
        {
            System.out.println("Chickens say: CLUCK CLUCK CLUCK");
        }
        
    public void eatFood(int num)
        {
            weight+=num;
        }
    
    public void displayChicken()
    {
        System.out.println("The chicken's breed: " + breed);
        System.out.println("The chicken's weight: " + weight);
        System.out.println("The chicken's number of eggs: " + eggs);
        System.out.println("Is the chicken mean?: " + mean);
    }
    
} //end cow class